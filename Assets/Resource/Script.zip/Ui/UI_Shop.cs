using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class UI_Shop : UIBase
{
    private void Start()
    {
        Shared.SoundManager.PlaySound(BGM);
    }

    //public void OnBtnOptionShow() => ToggleOptionWindow();
    //public void OnBtnBackLobby() => ChangeScene(eSCENE.eSCENE_LOBBY);
}
