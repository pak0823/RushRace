using UnityEngine;
using UnityEngine.UI;

public class UI_Stage : UIBase
{
    public GameObject checkWindow;
    public Text stageText;
    public bool isWindow = false;
    public GameObject []rockStage;

    private void Start()
    {
        Shared.UI_Stage = this;
        PlayBGM();

        if (GameManager.StageLevel.currentLevel >= StageData.CurrentStageNum)
        {
            int currentLevel = GameManager.StageLevel.currentLevel;

            if (currentLevel > 0 && rockStage[currentLevel] != null)
            {
                rockStage[currentLevel-1].gameObject.SetActive(false);
            }
            else
                return;
        }
        else
            return;
            
    }
    public void OnBtnYes() => ChangeScene(eSCENE.eSCENE_INGAME);
    public void OnBtnNo() => IsWindow(false);
    public void OnBtnBack() => Shared.SceneMgr.ChangeScene(eSCENE.eSCENE_LOBBY);

    public void IsWindow(bool _isshow)
    {
        checkWindow.gameObject.SetActive(_isshow);

        if(_isshow)
            isWindow = true;
        else
            isWindow = false;

        ClickSound();
    }
}