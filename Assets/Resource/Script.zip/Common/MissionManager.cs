using UnityEngine;
using UnityEngine.UI;

public class MissionManager : MonoBehaviour
{
    [Header("�̼� ����")]
    public int targetCoinCount = 10;
    public float missionTime = 60f;

    [Header("UI ���")]
    public Text timerText;
    public Text missionStatusText;

    private float remainingTime;
    private int currentCoinCount;
    private bool isMissionActive = false;

    void Start()
    {
        StartMission();
    }

    void Update()
    {
        if (!isMissionActive) return;

        remainingTime -= Time.deltaTime;
        timerText.text = $"{remainingTime:F1} ��";

        if (remainingTime <= 0)
        {
            EndMission(false);
        }
    }

    public void StartMission()
    {
        currentCoinCount = 0;
        remainingTime = missionTime;
        isMissionActive = true;
        missionStatusText.text = $"��ǥ ����: {targetCoinCount}";
    }

    public void OnCoinCollected()
    {
        if (!isMissionActive) return;

        currentCoinCount++;
        missionStatusText.text = $"���� {currentCoinCount}/{targetCoinCount}";

        if (currentCoinCount >= targetCoinCount)
        {
            EndMission(true);
        }
    }

    private void EndMission(bool success)
    {
        isMissionActive = false;

        if (success)
        {
            Shared.GameManager.AddMoney(currentCoinCount); // �� ���� ó��
            missionStatusText.text = "�̼� ����!";
        }
        else
        {
            missionStatusText.text = "�̼� ����";
        }
    }
}
